from django.contrib import admin
from .models import Item, Comment

admin.site.register(Item)
admin.site.register(Comment)